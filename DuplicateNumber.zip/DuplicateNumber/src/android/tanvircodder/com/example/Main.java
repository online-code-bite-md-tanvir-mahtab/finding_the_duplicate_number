package android.tanvircodder.com.example;

public class Main {
    // TODO: 1/20/2021 question to findout the duplicate number in the array list of 1 , 2, 3, 3, 4
    public static void main(String[] args) {
	// write your code here
//        first i am going to store the array data in the integer arrayv ariable..//
        int arr[] = {
                1,2,3,3,4
        };
//        printing the array..
        for (int i =0;i < arr.length; i++){
            System.out.println(arr[i]);
        }
//        nwo to find the duplicate number we are going to use the nested loop..
//        then we are going to use the condition to find the duplicate
        for (int i =0 ; i< arr.length; i++){
            for (int j = i + 1;j<arr.length; j++){
                if (arr[i] == arr[j]){
                    System.out.println("the duplicate number is: "+arr[j]);
                }
            }
        }
    }
}
